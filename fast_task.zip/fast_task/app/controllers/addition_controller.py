import time
from typing import List
from multiprocessing import Pool, cpu_count


def add_list_of_integers(payload: List[List[int]]) -> List[int]:
    return [sum(lst) for lst in payload]


def process_addition_task(batchid: str, payload: List[List[int]]) -> List[int]:
    start_time = time.time()

    # Use multiprocessing pool to perform addition
    with Pool(processes=cpu_count()) as pool:
        result = pool.apply_async(add_list_of_integers, (payload,))
        response = result.get()

    end_time = time.time()

    return response, start_time, end_time

from fastapi import FastAPI
from app.models.addition_models import RequestPayload, ResponsePayload
from app.controllers.addition_controller import process_addition_task

app = FastAPI()


@app.post("/addition")
async def addition(payload: RequestPayload) -> ResponsePayload:
    response, start_time, end_time = process_addition_task(payload.batchid, payload.payload)
    
    return ResponsePayload(
        batchid=payload.batchid,
        response=response,
        status="complete",
        started_at=start_time,
        completed_at=end_time
    )

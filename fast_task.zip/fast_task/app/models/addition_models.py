from typing import List
from pydantic import BaseModel


class RequestPayload(BaseModel):
    batchid: str
    payload: List[List[int]]


class ResponsePayload(BaseModel):
    batchid: str
    response: List[int]
    status: str
    started_at: float
    completed_at: float

    def __init__(self, **data):
        if 'started_at' in data:
            data['started_at'] = str(data['started_at'])
        if 'completed_at' in data:
            data['completed_at'] = str(data['completed_at'])
        super().__init__(**data)
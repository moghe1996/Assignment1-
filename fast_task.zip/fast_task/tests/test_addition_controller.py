from app.controllers.addition_controller import process_addition_task


def test_process_addition_task():
    batchid = "id0101"
    payload = [[1, 2], [3, 4]]

    response, start_time, end_time = process_addition_task(batchid, payload)

    assert isinstance(response, list)
    assert len(response) == 2
    assert start_time < end_time
